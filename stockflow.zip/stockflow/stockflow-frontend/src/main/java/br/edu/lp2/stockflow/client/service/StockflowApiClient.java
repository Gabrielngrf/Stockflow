package br.edu.lp2.stockflow.client.service;

import br.edu.lp2.stockflow.client.model.ClassificacaoRequestDTO;
import br.edu.lp2.stockflow.client.model.ComentarioRequestDTO;
import br.edu.lp2.stockflow.client.model.LivroDTO;
import br.edu.lp2.stockflow.client.model.MovimentacaoDTO;
import br.edu.lp2.stockflow.client.model.MovimentacaoRequestDTO;
import br.edu.lp2.stockflow.client.model.TipoMovimentacao;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.io.IOException;
import java.net.http.HttpRequest.BodyPublisher;
import java.net.http.HttpRequest.BodyPublishers;
import java.nio.file.Files;
import java.nio.file.Path;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;

public class StockflowApiClient {
    private static final String BASE_URL = "http://localhost:8080";

    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

    public List<LivroDTO> listarLivros(String titulo) {
        String path = "/livros";
        if (titulo != null && !titulo.isBlank()) {
            path += "?titulo=" + URLEncoder.encode(titulo, StandardCharsets.UTF_8);
        }
        return sendListRequest(path, new TypeReference<>() {});
    }

    public LivroDTO salvarLivro(LivroDTO livro) {
        boolean novo = livro.getId() == null;
        String path = novo ? "/livros" : "/livros/" + livro.getId();
        String method = novo ? "POST" : "PUT";
        return sendBodyRequest(path, method, livro, LivroDTO.class);
    }

    public void removerLivro(Long id) {
        sendNoBodyRequest("/livros/" + id, "DELETE");
    }

    public LivroDTO enviarImagem(Long livroId, Path imagem) {
        return sendMultipartRequest("/livros/" + livroId + "/imagem", imagem, LivroDTO.class);
    }

    public LivroDTO classificarLivro(Long livroId, String usuario, int nota) {
        return sendBodyRequest("/livros/" + livroId + "/classificacoes", "POST",
                new ClassificacaoRequestDTO(usuario, nota), LivroDTO.class);
    }

    public LivroDTO adicionarComentario(Long livroId, String autor, String texto) {
        return sendBodyRequest("/livros/" + livroId + "/comentarios", "POST",
                new ComentarioRequestDTO(autor, texto), LivroDTO.class);
    }

    public List<LivroDTO> listarAlertas() {
        return sendListRequest("/livros/alertas", new TypeReference<>() {});
    }

    public List<MovimentacaoDTO> listarMovimentacoes(TipoMovimentacao tipo) {
        String path = tipo == null ? "/movimentacoes" : "/movimentacoes?tipo=" + tipo;
        return sendListRequest(path, new TypeReference<>() {});
    }

    public MovimentacaoDTO registrarEntrada(Long livroId, int quantidade) {
        return sendBodyRequest("/movimentacoes/entrada", "POST",
                new MovimentacaoRequestDTO(livroId, quantidade), MovimentacaoDTO.class);
    }

    public MovimentacaoDTO registrarSaida(Long livroId, int quantidade) {
        return sendBodyRequest("/movimentacoes/saida", "POST",
                new MovimentacaoRequestDTO(livroId, quantidade), MovimentacaoDTO.class);
    }

    private <T> List<T> sendListRequest(String path, TypeReference<List<T>> typeReference) {
        try {
            HttpRequest request = HttpRequest.newBuilder(URI.create(BASE_URL + path)).GET().build();
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            validarResposta(response);
            return objectMapper.readValue(response.body(), typeReference);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ApiException("Operacao interrompida durante a comunicacao com o backend.");
        } catch (IOException e) {
            throw new ApiException("Nao foi possivel conectar ao backend. Verifique se a API esta em execucao.");
        }
    }

    private <T> T sendBodyRequest(String path, String method, Object body, Class<T> responseType) {
        try {
            String json = objectMapper.writeValueAsString(body);
            HttpRequest request = HttpRequest.newBuilder(URI.create(BASE_URL + path))
                    .header("Content-Type", "application/json")
                    .method(method, HttpRequest.BodyPublishers.ofString(json))
                    .build();
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            validarResposta(response);
            return objectMapper.readValue(response.body(), responseType);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ApiException("Operacao interrompida durante a comunicacao com o backend.");
        } catch (IOException e) {
            throw new ApiException("Nao foi possivel comunicar com a API: " + e.getMessage());
        }
    }

    private void sendNoBodyRequest(String path, String method) {
        try {
            HttpRequest request = HttpRequest.newBuilder(URI.create(BASE_URL + path))
                    .method(method, HttpRequest.BodyPublishers.noBody())
                    .build();
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            validarResposta(response);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ApiException("Operacao interrompida durante a comunicacao com o backend.");
        } catch (IOException e) {
            throw new ApiException("Nao foi possivel comunicar com a API: " + e.getMessage());
        }
    }

    private <T> T sendMultipartRequest(String path, Path arquivo, Class<T> responseType) {
        try {
            String boundary = "StockFlowBoundary" + UUID.randomUUID();
            HttpRequest request = HttpRequest.newBuilder(URI.create(BASE_URL + path))
                    .header("Content-Type", "multipart/form-data; boundary=" + boundary)
                    .POST(criarMultipartBody(arquivo, boundary))
                    .build();
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            validarResposta(response);
            return objectMapper.readValue(response.body(), responseType);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ApiException("Operacao interrompida durante o envio da imagem.");
        } catch (IOException e) {
            throw new ApiException("Nao foi possivel enviar a imagem: " + e.getMessage());
        }
    }

    private BodyPublisher criarMultipartBody(Path arquivo, String boundary) throws IOException {
        String nomeArquivo = arquivo.getFileName().toString();
        String tipo = Files.probeContentType(arquivo);
        if (tipo == null) {
            tipo = "application/octet-stream";
        }

        byte[] inicio = ("--" + boundary + "\r\n"
                + "Content-Disposition: form-data; name=\"arquivo\"; filename=\"" + nomeArquivo + "\"\r\n"
                + "Content-Type: " + tipo + "\r\n\r\n").getBytes(StandardCharsets.UTF_8);
        byte[] conteudo = Files.readAllBytes(arquivo);
        byte[] fim = ("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8);

        return BodyPublishers.ofByteArrays(List.of(inicio, conteudo, fim));
    }

    private void validarResposta(HttpResponse<String> response) {
        if (response.statusCode() >= 400) {
            throw new ApiException("Erro da API (" + response.statusCode() + "): " + response.body());
        }
    }
}
