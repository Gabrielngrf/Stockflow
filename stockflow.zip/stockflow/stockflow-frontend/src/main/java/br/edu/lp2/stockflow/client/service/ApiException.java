package br.edu.lp2.stockflow.client.service;

public class ApiException extends RuntimeException {
    public ApiException(String message) {
        super(message);
    }
}
