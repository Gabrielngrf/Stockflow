package br.edu.lp2.stockflow.client;

public class ClientLauncher {

    public static void main(String[] args) {
        StockflowClientApplication.main(args);
    }
}
