package br.edu.lp2.stockflow.client.model;

public class MovimentacaoRequestDTO {
    private Long livroId;
    private int quantidade;

    public MovimentacaoRequestDTO() {
    }

    public MovimentacaoRequestDTO(Long livroId, int quantidade) {
        this.livroId = livroId;
        this.quantidade = quantidade;
    }

    public Long getLivroId() {
        return livroId;
    }

    public void setLivroId(Long livroId) {
        this.livroId = livroId;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
}
