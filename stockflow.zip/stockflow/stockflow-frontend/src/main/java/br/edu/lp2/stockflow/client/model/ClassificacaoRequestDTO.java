package br.edu.lp2.stockflow.client.model;

public class ClassificacaoRequestDTO {
    private String usuario;
    private int nota;

    public ClassificacaoRequestDTO() {
    }

    public ClassificacaoRequestDTO(String usuario, int nota) {
        this.usuario = usuario;
        this.nota = nota;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }
}
