package br.edu.lp2.stockflow.client.controller;

import br.edu.lp2.stockflow.client.model.ComentarioDTO;
import br.edu.lp2.stockflow.client.model.LivroDTO;
import br.edu.lp2.stockflow.client.model.MovimentacaoDTO;
import br.edu.lp2.stockflow.client.model.TipoEstoque;
import br.edu.lp2.stockflow.client.model.TipoMovimentacao;
import br.edu.lp2.stockflow.client.service.ApiException;
import br.edu.lp2.stockflow.client.service.StockflowApiClient;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

import java.io.File;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class MainController {
    private final StockflowApiClient apiClient = new StockflowApiClient();
    private final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("pt", "BR"));
    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    @FXML private TextField buscaTituloField;
    @FXML private TableView<LivroDTO> livrosTable;
    @FXML private TableColumn<LivroDTO, String> idColumn;
    @FXML private TableColumn<LivroDTO, String> tituloColumn;
    @FXML private TableColumn<LivroDTO, String> autorColumn;
    @FXML private TableColumn<LivroDTO, String> categoriaColumn;
    @FXML private TableColumn<LivroDTO, String> precoColumn;
    @FXML private TableColumn<LivroDTO, String> quantidadeColumn;
    @FXML private TableColumn<LivroDTO, String> minimoColumn;
    @FXML private TableColumn<LivroDTO, String> tipoEstoqueColumn;

    @FXML private TextField idField;
    @FXML private TextField tituloField;
    @FXML private TextField autorField;
    @FXML private TextField categoriaField;
    @FXML private TextField precoField;
    @FXML private Spinner<Integer> quantidadeSpinner;
    @FXML private Spinner<Integer> estoqueMinimoSpinner;
    @FXML private ComboBox<TipoEstoque> tipoEstoqueCombo;
    @FXML private ImageView capaImageView;
    @FXML private Label mediaClassificacaoLabel;
    @FXML private TextField usuarioAvaliacaoField;
    @FXML private Spinner<Integer> notaSpinner;
    @FXML private TextField autorComentarioField;
    @FXML private TextArea comentarioTextArea;
    @FXML private ListView<String> comentariosListView;

    @FXML private Spinner<Integer> movimentacaoQuantidadeSpinner;
    @FXML private Button entradaButton;
    @FXML private Button saidaButton;

    @FXML private TableView<MovimentacaoDTO> movimentacoesTable;
    @FXML private TableColumn<MovimentacaoDTO, String> movIdColumn;
    @FXML private TableColumn<MovimentacaoDTO, String> movLivroColumn;
    @FXML private TableColumn<MovimentacaoDTO, String> movTipoColumn;
    @FXML private TableColumn<MovimentacaoDTO, String> movQuantidadeColumn;
    @FXML private TableColumn<MovimentacaoDTO, String> movDataColumn;
    @FXML private ComboBox<TipoMovimentacao> relatorioTipoCombo;
    @FXML private Label statusLabel;

    @FXML
    public void initialize() {
        configurarTabelaLivros();
        configurarTabelaMovimentacoes();
        configurarFormulario();
        carregarDados();
    }

    @FXML
    private void buscarLivros() {
        executarComTratamento(() -> livrosTable.setItems(FXCollections.observableArrayList(
                apiClient.listarLivros(buscaTituloField.getText()))));
    }

    @FXML
    private void salvarLivro() {
        executarComTratamento(() -> {
            LivroDTO livro = criarLivroDoFormulario();
            LivroDTO salvo = apiClient.salvarLivro(livro);
            limparFormulario();
            carregarDados();
            selecionarLivro(salvo.getId());
            statusLabel.setText("Livro salvo com sucesso.");
        });
    }

    @FXML
    private void removerLivro() {
        LivroDTO selecionado = livrosTable.getSelectionModel().getSelectedItem();
        if (selecionado == null) {
            mostrarAviso("Selecione um livro para remover.");
            return;
        }
        executarComTratamento(() -> {
            apiClient.removerLivro(selecionado.getId());
            limparFormulario();
            carregarDados();
            statusLabel.setText("Livro removido.");
        });
    }

    @FXML
    private void limparFormulario() {
        idField.clear();
        tituloField.clear();
        autorField.clear();
        categoriaField.clear();
        precoField.clear();
        quantidadeSpinner.getValueFactory().setValue(0);
        estoqueMinimoSpinner.getValueFactory().setValue(0);
        tipoEstoqueCombo.getSelectionModel().select(TipoEstoque.FISICO);
        capaImageView.setImage(null);
        mediaClassificacaoLabel.setText("Media: 0.0 (0 avaliacoes)");
        usuarioAvaliacaoField.clear();
        notaSpinner.getValueFactory().setValue(5);
        autorComentarioField.clear();
        comentarioTextArea.clear();
        comentariosListView.getItems().clear();
        livrosTable.getSelectionModel().clearSelection();
    }

    @FXML
    private void registrarEntrada() {
        registrarMovimentacao(true);
    }

    @FXML
    private void registrarSaida() {
        registrarMovimentacao(false);
    }

    @FXML
    private void carregarAlertas() {
        executarComTratamento(() -> {
            livrosTable.setItems(FXCollections.observableArrayList(apiClient.listarAlertas()));
            statusLabel.setText("Exibindo livros abaixo do estoque minimo.");
        });
    }

    @FXML
    private void carregarRelatorio() {
        executarComTratamento(() -> movimentacoesTable.setItems(FXCollections.observableArrayList(
                apiClient.listarMovimentacoes(relatorioTipoCombo.getValue()))));
    }

    @FXML
    private void carregarTodos() {
        buscaTituloField.clear();
        relatorioTipoCombo.getSelectionModel().clearSelection();
        carregarDados();
    }

    @FXML
    private void selecionarImagem() {
        LivroDTO selecionado = livrosTable.getSelectionModel().getSelectedItem();
        if (selecionado == null || selecionado.getId() == null) {
            mostrarAviso("Salve e selecione um livro antes de enviar a imagem.");
            return;
        }

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Selecionar imagem do livro");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter(
                "Imagens", "*.jpg", "*.jpeg", "*.png", "*.gif", "*.webp"));
        File arquivo = fileChooser.showOpenDialog(livrosTable.getScene().getWindow());
        if (arquivo == null) {
            return;
        }

        executarComTratamento(() -> {
            LivroDTO atualizado = apiClient.enviarImagem(selecionado.getId(), arquivo.toPath());
            carregarDados();
            selecionarLivro(atualizado.getId());
            statusLabel.setText("Imagem salva.");
        });
    }

    @FXML
    private void salvarAvaliacao() {
        LivroDTO selecionado = livrosTable.getSelectionModel().getSelectedItem();
        if (selecionado == null) {
            mostrarAviso("Selecione um livro para avaliar.");
            return;
        }

        executarComTratamento(() -> {
            LivroDTO atualizado = apiClient.classificarLivro(
                    selecionado.getId(),
                    obrigatorio(usuarioAvaliacaoField, "Usuario"),
                    notaSpinner.getValue()
            );
            carregarDados();
            selecionarLivro(atualizado.getId());
            statusLabel.setText("Avaliacao salva.");
        });
    }

    @FXML
    private void adicionarComentario() {
        LivroDTO selecionado = livrosTable.getSelectionModel().getSelectedItem();
        if (selecionado == null) {
            mostrarAviso("Selecione um livro para comentar.");
            return;
        }

        executarComTratamento(() -> {
            LivroDTO atualizado = apiClient.adicionarComentario(
                    selecionado.getId(),
                    obrigatorio(autorComentarioField, "Autor do comentario"),
                    obrigatorio(comentarioTextArea, "Comentario")
            );
            comentarioTextArea.clear();
            carregarDados();
            selecionarLivro(atualizado.getId());
            statusLabel.setText("Comentario adicionado.");
        });
    }

    private void configurarTabelaLivros() {
        idColumn.setCellValueFactory(cell -> texto(cell.getValue().getId()));
        tituloColumn.setCellValueFactory(cell -> texto(cell.getValue().getTitulo()));
        autorColumn.setCellValueFactory(cell -> texto(cell.getValue().getAutor()));
        categoriaColumn.setCellValueFactory(cell -> texto(cell.getValue().getCategoria()));
        precoColumn.setCellValueFactory(cell -> texto(currencyFormat.format(cell.getValue().getPreco())));
        quantidadeColumn.setCellValueFactory(cell -> texto(cell.getValue().getQuantidade()));
        minimoColumn.setCellValueFactory(cell -> texto(cell.getValue().getEstoqueMinimo()));
        tipoEstoqueColumn.setCellValueFactory(cell -> texto(cell.getValue().getTipoEstoque()));

        livrosTable.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, livro) -> {
            if (livro != null) {
                preencherFormulario(livro);
            }
        });
    }

    private void configurarTabelaMovimentacoes() {
        movIdColumn.setCellValueFactory(cell -> texto(cell.getValue().getId()));
        movLivroColumn.setCellValueFactory(cell -> texto(cell.getValue().getLivroId() + " - " + valorOuVazio(cell.getValue().getTituloLivro())));
        movTipoColumn.setCellValueFactory(cell -> texto(cell.getValue().getTipo()));
        movQuantidadeColumn.setCellValueFactory(cell -> texto(cell.getValue().getQuantidade()));
        movDataColumn.setCellValueFactory(cell -> texto(cell.getValue().getDataHora() == null ? "" : cell.getValue().getDataHora().format(dateFormatter)));
    }

    private void configurarFormulario() {
        quantidadeSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 99999, 0));
        estoqueMinimoSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 99999, 0));
        movimentacaoQuantidadeSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 99999, 1));
        notaSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 5, 5));
        tipoEstoqueCombo.setItems(FXCollections.observableArrayList(TipoEstoque.values()));
        tipoEstoqueCombo.getSelectionModel().select(TipoEstoque.FISICO);
        relatorioTipoCombo.setItems(FXCollections.observableArrayList(TipoMovimentacao.values()));
    }

    private void carregarDados() {
        executarComTratamento(() -> {
            livrosTable.setItems(FXCollections.observableArrayList(apiClient.listarLivros(null)));
            movimentacoesTable.setItems(FXCollections.observableArrayList(apiClient.listarMovimentacoes(null)));
            statusLabel.setText("Dados atualizados.");
        });
    }

    private LivroDTO criarLivroDoFormulario() {
        LivroDTO livro = new LivroDTO();
        if (!idField.getText().isBlank()) {
            livro.setId(Long.parseLong(idField.getText()));
        }
        livro.setTitulo(obrigatorio(tituloField, "Titulo"));
        livro.setAutor(obrigatorio(autorField, "Autor"));
        livro.setCategoria(obrigatorio(categoriaField, "Categoria"));
        livro.setPreco(new BigDecimal(obrigatorio(precoField, "Preco").replace(",", ".")));
        livro.setQuantidade(quantidadeSpinner.getValue());
        livro.setEstoqueMinimo(estoqueMinimoSpinner.getValue());
        livro.setTipoEstoque(tipoEstoqueCombo.getValue());
        return livro;
    }

    private void preencherFormulario(LivroDTO livro) {
        idField.setText(String.valueOf(livro.getId()));
        tituloField.setText(livro.getTitulo());
        autorField.setText(livro.getAutor());
        categoriaField.setText(livro.getCategoria());
        precoField.setText(livro.getPreco().toPlainString());
        quantidadeSpinner.getValueFactory().setValue(livro.getQuantidade());
        estoqueMinimoSpinner.getValueFactory().setValue(livro.getEstoqueMinimo());
        tipoEstoqueCombo.getSelectionModel().select(livro.getTipoEstoque());
        atualizarDetalhesLivro(livro);
    }

    private void registrarMovimentacao(boolean entrada) {
        LivroDTO selecionado = livrosTable.getSelectionModel().getSelectedItem();
        if (selecionado == null) {
            mostrarAviso("Selecione um livro para movimentar o estoque.");
            return;
        }
        executarComTratamento(() -> {
            if (entrada) {
                apiClient.registrarEntrada(selecionado.getId(), movimentacaoQuantidadeSpinner.getValue());
            } else {
                apiClient.registrarSaida(selecionado.getId(), movimentacaoQuantidadeSpinner.getValue());
            }
            carregarDados();
            selecionarLivro(selecionado.getId());
            statusLabel.setText(entrada ? "Entrada registrada." : "Saida registrada.");
        });
    }

    private void selecionarLivro(Long id) {
        livrosTable.getItems().stream()
                .filter(livro -> livro.getId().equals(id))
                .findFirst()
                .ifPresent(livro -> livrosTable.getSelectionModel().select(livro));
    }

    private String obrigatorio(TextField field, String nome) {
        String valor = field.getText();
        if (valor == null || valor.isBlank()) {
            throw new ApiException(nome + " e obrigatorio.");
        }
        return valor.trim();
    }

    private String obrigatorio(TextArea field, String nome) {
        String valor = field.getText();
        if (valor == null || valor.isBlank()) {
            throw new ApiException(nome + " e obrigatorio.");
        }
        return valor.trim();
    }

    private void atualizarDetalhesLivro(LivroDTO livro) {
        mediaClassificacaoLabel.setText(String.format(Locale.US, "Media: %.1f (%d avaliacoes)",
                livro.getMediaClassificacao(), livro.getTotalClassificacoes()));
        comentariosListView.setItems(FXCollections.observableArrayList(
                livro.getComentarios().stream().map(this::formatarComentario).toList()));

        if (livro.getImagemUrl() == null || livro.getImagemUrl().isBlank()) {
            capaImageView.setImage(null);
        } else {
            String url = "http://localhost:8080" + livro.getImagemUrl() + "?v=" + System.currentTimeMillis();
            capaImageView.setImage(new Image(url, true));
        }
    }

    private String formatarComentario(ComentarioDTO comentario) {
        String data = comentario.getDataHora() == null ? "" : comentario.getDataHora().format(dateFormatter);
        return comentario.getAutor() + " - " + data + System.lineSeparator() + comentario.getTexto();
    }

    private SimpleStringProperty texto(Object valor) {
        return new SimpleStringProperty(valor == null ? "" : String.valueOf(valor));
    }

    private String valorOuVazio(String valor) {
        return valor == null ? "" : valor;
    }

    private void executarComTratamento(Runnable acao) {
        try {
            acao.run();
        } catch (Exception ex) {
            mostrarErro(ex.getMessage());
        }
    }

    private void mostrarAviso(String mensagem) {
        mostrarAlerta(Alert.AlertType.WARNING, "Atencao", mensagem);
    }

    private void mostrarErro(String mensagem) {
        mostrarAlerta(Alert.AlertType.ERROR, "Erro", mensagem);
        statusLabel.setText("Erro na operacao.");
    }

    private void mostrarAlerta(Alert.AlertType tipo, String titulo, String mensagem) {
        Platform.runLater(() -> {
            Alert alert = new Alert(tipo);
            alert.setTitle(titulo);
            alert.setHeaderText(null);
            alert.setContentText(mensagem);
            alert.showAndWait();
        });
    }
}
