package br.edu.lp2.stockflow.client.model;

public class ComentarioRequestDTO {
    private String autor;
    private String texto;

    public ComentarioRequestDTO() {
    }

    public ComentarioRequestDTO(String autor, String texto) {
        this.autor = autor;
        this.texto = texto;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }
}
