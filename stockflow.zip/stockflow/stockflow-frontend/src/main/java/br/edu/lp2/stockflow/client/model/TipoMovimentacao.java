package br.edu.lp2.stockflow.client.model;

public enum TipoMovimentacao {
    ENTRADA,
    SAIDA
}
