# StockFlow - Sistema de Controle de Estoque para Livrarias

Projeto cliente-servidor para a disciplina de Linguagem de Programacao 2. O backend usa Java 17, Spring Boot 3, Swagger/OpenAPI e persistencia em arquivos JSON. O frontend usa JavaFX, FXML e comunicacao HTTP com `HttpClient`.

## Estrutura

```text
stockflow
├── pom.xml
├── stockflow-backend
│   ├── pom.xml
│   ├── data
│   │   ├── livros.json
│   │   └── movimentacoes.json
│   └── src/main/java/br/edu/lp2/stockflow
│       ├── config
│       ├── controller
│       ├── dto
│       ├── exception
│       ├── model
│       ├── repository
│       └── service
└── stockflow-frontend
    ├── pom.xml
    └── src/main
        ├── java/br/edu/lp2/stockflow/client
        │   ├── controller
        │   ├── model
        │   └── service
        └── resources
            ├── css
            └── fxml
```

## Como executar

Requisitos: JDK 17 ou superior e Maven configurado no PATH.

Backend:

```bash
cd stockflow-backend
mvn spring-boot:run
```

API: `http://localhost:8080`

Swagger: `http://localhost:8080/swagger-ui/index.html`

Frontend, em outro terminal:

```bash
cd stockflow-frontend
mvn javafx:run
```

No IntelliJ IDEA, abra a pasta `stockflow`, aguarde a importacao Maven e execute:

- Backend: classe `br.edu.lp2.stockflow.StockflowBackendApplication`
- Frontend: plugin Maven `stockflow-frontend > javafx:run` ou classe `br.edu.lp2.stockflow.client.StockflowClientApplication`

## Endpoints

- `GET /livros`: lista todos os livros.
- `GET /livros?titulo=clean`: busca livros por titulo.
- `GET /livros/{id}`: busca livro por ID.
- `POST /livros`: cadastra livro.
- `PUT /livros/{id}`: edita livro.
- `DELETE /livros/{id}`: remove livro.
- `GET /livros/alertas`: lista livros abaixo do estoque minimo.
- `GET /livros/{id}/quantidade`: consulta quantidade disponivel.
- `POST /livros/{id}/imagem`: envia imagem do livro via `multipart/form-data`.
- `GET /livros/{id}/imagem`: retorna a imagem cadastrada.
- `POST /livros/{id}/classificacoes`: registra ou altera a classificacao de um usuario.
- `POST /livros/{id}/comentarios`: adiciona comentario ao livro.
- `GET /movimentacoes`: historico completo.
- `GET /movimentacoes?tipo=ENTRADA`: relatorio de entradas.
- `GET /movimentacoes?tipo=SAIDA`: relatorio de saidas.
- `POST /movimentacoes/entrada`: registra entrada.
- `POST /movimentacoes/saida`: registra saida.

## Exemplos de requisicoes

Cadastrar livro:

```bash
curl -X POST http://localhost:8080/livros \
  -H "Content-Type: application/json" \
  -d '{"titulo":"Effective Java","autor":"Joshua Bloch","categoria":"Programacao","preco":189.90,"quantidade":5,"estoqueMinimo":2,"tipoEstoque":"FISICO"}'
```

Editar livro:

```bash
curl -X PUT http://localhost:8080/livros/1 \
  -H "Content-Type: application/json" \
  -d '{"titulo":"Clean Code","autor":"Robert C. Martin","categoria":"Programacao","preco":159.90,"quantidade":8,"estoqueMinimo":3,"tipoEstoque":"FISICO"}'
```

Registrar entrada:

```bash
curl -X POST http://localhost:8080/movimentacoes/entrada \
  -H "Content-Type: application/json" \
  -d '{"livroId":1,"quantidade":4}'
```

Registrar saida:

```bash
curl -X POST http://localhost:8080/movimentacoes/saida \
  -H "Content-Type: application/json" \
  -d '{"livroId":1,"quantidade":2}'
```

Consultar alertas:

```bash
curl http://localhost:8080/livros/alertas
```

Enviar imagem do livro:

```bash
curl -X POST http://localhost:8080/livros/1/imagem \
  -F "arquivo=@C:/caminho/para/capa.png"
```

Classificar livro:

```bash
curl -X POST http://localhost:8080/livros/1/classificacoes \
  -H "Content-Type: application/json" \
  -d '{"usuario":"Gabriel","nota":5}'
```

Alterar a classificacao uma vez:

```bash
curl -X POST http://localhost:8080/livros/1/classificacoes \
  -H "Content-Type: application/json" \
  -d '{"usuario":"Gabriel","nota":4}'
```

Se o mesmo usuario tentar alterar novamente o mesmo livro, a API retorna erro de regra de negocio.

Adicionar comentario:

```bash
curl -X POST http://localhost:8080/livros/1/comentarios \
  -H "Content-Type: application/json" \
  -d '{"autor":"Gabriel","texto":"Livro excelente para estudar boas praticas."}'
```

## Classes principais

### Backend

- `StockflowBackendApplication`: ponto de entrada da API Spring Boot.
- `OpenApiConfig`: configura titulo, versao e descricao da documentacao Swagger.
- `Livro` e `Movimentacao`: modelos de dominio com encapsulamento, atributos privados e metodos de acesso.
- `Comentario` e `Classificacao`: modelos usados dentro de `Livro` para registrar opinioes, notas e controle de alteracao de avaliacao.
- `TipoEstoque` e `TipoMovimentacao`: enums que limitam valores validos para estoque e movimentacoes.
- `LivroRequestDTO` e `MovimentacaoRequestDTO`: DTOs de entrada com validacoes via Bean Validation.
- `ComentarioRequestDTO` e `ClassificacaoRequestDTO`: DTOs de entrada para comentarios e notas; a nota e validada entre 1 e 5.
- `LivroResponseDTO`, `MovimentacaoResponseDTO` e `ErrorResponseDTO`: DTOs de saida da API.
- `ComentarioResponseDTO`: DTO de saida para comentarios do livro.
- `JsonFileRepository`: classe base para leitura e escrita sincronizada em arquivos JSON.
- `LivroRepository`: persistencia de livros em `data/livros.json`.
- `MovimentacaoRepository`: persistencia de movimentacoes em `data/movimentacoes.json`.
- `LivroService`: regras de cadastro, edicao, remocao, busca e alertas.
- `ImagemService`: valida extensao, salva imagens em `data/imagens` e resolve o arquivo para exibicao.
- `LivroService`: tambem calcula media de classificacao, adiciona comentarios e permite uma unica alteracao de nota por usuario/livro.
- `MovimentacaoService`: regras de entrada, saida, atualizacao de quantidade e relatorios.
- `LivroController`: endpoints REST de livros e alertas.
- `MovimentacaoController`: endpoints REST de movimentacoes.
- `GlobalExceptionHandler`: tratamento padronizado de erros de validacao, negocio e recursos inexistentes.

### Frontend

- `StockflowClientApplication`: inicializa a janela JavaFX e carrega o FXML.
- `main-view.fxml`: tela principal com abas de livros/estoque e relatorios.
- `styles.css`: estilo visual da interface.
- `MainController`: controla eventos da tela, tabelas, formulario, movimentacoes e mensagens.
- `StockflowApiClient`: cliente HTTP que chama a API usando `HttpClient`.
- `StockflowApiClient`: tambem monta requisicao `multipart/form-data` para envio de imagem.
- `ApiException`: excecao do cliente para falhas de API ou conexao.
- DTOs e enums em `client.model`: representam dados recebidos e enviados ao backend.

## Persistencia JSON

Os arquivos ficam em `stockflow-backend/data`. Ao iniciar, se os arquivos nao existirem, eles sao criados automaticamente com lista vazia. O projeto ja inclui dados iniciais em `livros.json`.

Cada livro armazena no JSON:

- dados cadastrais e estoque;
- `imagemPath`, apontando para uma imagem em `data/imagens`;
- `comentarios`, com autor, texto e data;
- `classificacoes`, com usuario, nota, data e controle se a avaliacao ja foi alterada.

## Como usar as novas funcoes no JavaFX

1. Selecione um livro na tabela.
2. Clique em `Selecionar imagem` para anexar uma capa local. A imagem sera copiada para `stockflow-backend/data/imagens` e exibida no painel.
3. Em `Avaliacao`, informe o usuario e escolha uma nota de 1 a 5.
4. Clique em `Salvar avaliacao`. O mesmo usuario pode alterar essa nota apenas uma vez para o mesmo livro.
5. Em `Comentarios`, informe seu nome e o texto.
6. Clique em `Adicionar comentario`. A lista abaixo mostra os comentarios do livro selecionado.
