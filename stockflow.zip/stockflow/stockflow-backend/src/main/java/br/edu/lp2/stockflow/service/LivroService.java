package br.edu.lp2.stockflow.service;

import br.edu.lp2.stockflow.dto.ClassificacaoRequestDTO;
import br.edu.lp2.stockflow.dto.ComentarioRequestDTO;
import br.edu.lp2.stockflow.dto.ComentarioResponseDTO;
import br.edu.lp2.stockflow.dto.LivroRequestDTO;
import br.edu.lp2.stockflow.dto.LivroResponseDTO;
import br.edu.lp2.stockflow.exception.RecursoNaoEncontradoException;
import br.edu.lp2.stockflow.exception.RegraNegocioException;
import br.edu.lp2.stockflow.model.Classificacao;
import br.edu.lp2.stockflow.model.Comentario;
import br.edu.lp2.stockflow.model.Livro;
import br.edu.lp2.stockflow.repository.LivroRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Locale;

@Service
public class LivroService {
    private final LivroRepository livroRepository;
    private final ImagemService imagemService;

    public LivroService(LivroRepository livroRepository, ImagemService imagemService) {
        this.livroRepository = livroRepository;
        this.imagemService = imagemService;
    }

    public List<LivroResponseDTO> listar(String titulo) {
        List<Livro> livros = titulo == null || titulo.isBlank()
                ? livroRepository.findAll()
                : livroRepository.findByTitulo(titulo);
        return livros.stream().map(this::toResponse).toList();
    }

    public LivroResponseDTO buscarPorId(Long id) {
        return toResponse(buscarEntidadePorId(id));
    }

    public LivroResponseDTO cadastrar(LivroRequestDTO request) {
        Livro livro = toEntity(request);
        return toResponse(livroRepository.save(livro));
    }

    public LivroResponseDTO atualizar(Long id, LivroRequestDTO request) {
        Livro existente = buscarEntidadePorId(id);
        Livro livro = toEntity(request);
        livro.setId(id);
        livro.setImagemPath(existente.getImagemPath());
        livro.setComentarios(existente.getComentarios());
        livro.setClassificacoes(existente.getClassificacoes());
        return toResponse(livroRepository.save(livro));
    }

    public void remover(Long id) {
        buscarEntidadePorId(id);
        livroRepository.deleteById(id);
    }

    public List<LivroResponseDTO> listarAlertas() {
        return livroRepository.findAll().stream()
                .filter(Livro::abaixoDoEstoqueMinimo)
                .map(this::toResponse)
                .toList();
    }

    public int consultarQuantidade(Long id) {
        return buscarEntidadePorId(id).getQuantidade();
    }

    public LivroResponseDTO salvarImagem(Long id, MultipartFile arquivo) {
        Livro livro = buscarEntidadePorId(id);
        livro.setImagemPath(imagemService.salvarImagem(arquivo));
        return toResponse(livroRepository.save(livro));
    }

    public LivroResponseDTO adicionarComentario(Long id, ComentarioRequestDTO request) {
        Livro livro = buscarEntidadePorId(id);
        Comentario comentario = new Comentario(
                request.getAutor().trim(),
                request.getTexto().trim(),
                LocalDateTime.now()
        );
        livro.getComentarios().add(comentario);
        return toResponse(livroRepository.save(livro));
    }

    public LivroResponseDTO classificar(Long id, ClassificacaoRequestDTO request) {
        Livro livro = buscarEntidadePorId(id);
        String usuario = normalizarUsuario(request.getUsuario());

        Classificacao existente = livro.getClassificacoes().stream()
                .filter(classificacao -> normalizarUsuario(classificacao.getUsuario()).equals(usuario))
                .findFirst()
                .orElse(null);

        if (existente == null) {
            livro.getClassificacoes().add(new Classificacao(request.getUsuario().trim(), request.getNota(), false, LocalDateTime.now()));
        } else if (!existente.isAlterada()) {
            existente.setNota(request.getNota());
            existente.setAlterada(true);
            existente.setDataHora(LocalDateTime.now());
        } else {
            throw new RegraNegocioException("Este usuario ja alterou a avaliacao uma vez para este livro");
        }

        return toResponse(livroRepository.save(livro));
    }

    public Livro buscarEntidadePorId(Long id) {
        return livroRepository.findById(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Livro nao encontrado com ID " + id));
    }

    LivroResponseDTO toResponse(Livro livro) {
        LivroResponseDTO dto = new LivroResponseDTO();
        dto.setId(livro.getId());
        dto.setTitulo(livro.getTitulo());
        dto.setAutor(livro.getAutor());
        dto.setCategoria(livro.getCategoria());
        dto.setPreco(livro.getPreco());
        dto.setQuantidade(livro.getQuantidade());
        dto.setEstoqueMinimo(livro.getEstoqueMinimo());
        dto.setTipoEstoque(livro.getTipoEstoque());
        dto.setImagemPath(livro.getImagemPath());
        dto.setImagemUrl(livro.getImagemPath() == null ? null : "/livros/" + livro.getId() + "/imagem");
        dto.setTotalClassificacoes(livro.getClassificacoes().size());
        dto.setMediaClassificacao(calcularMedia(livro));
        dto.setComentarios(livro.getComentarios().stream().map(this::toComentarioResponse).toList());
        return dto;
    }

    private Livro toEntity(LivroRequestDTO dto) {
        Livro livro = new Livro();
        livro.setTitulo(dto.getTitulo().trim());
        livro.setAutor(dto.getAutor().trim());
        livro.setCategoria(dto.getCategoria().trim());
        livro.setPreco(dto.getPreco());
        livro.setQuantidade(dto.getQuantidade());
        livro.setEstoqueMinimo(dto.getEstoqueMinimo());
        livro.setTipoEstoque(dto.getTipoEstoque());
        return livro;
    }

    private ComentarioResponseDTO toComentarioResponse(Comentario comentario) {
        ComentarioResponseDTO dto = new ComentarioResponseDTO();
        dto.setAutor(comentario.getAutor());
        dto.setTexto(comentario.getTexto());
        dto.setDataHora(comentario.getDataHora());
        return dto;
    }

    private double calcularMedia(Livro livro) {
        return livro.getClassificacoes().stream()
                .mapToInt(Classificacao::getNota)
                .average()
                .orElse(0.0);
    }

    private String normalizarUsuario(String usuario) {
        return usuario == null ? "" : usuario.trim().toLowerCase(Locale.ROOT);
    }
}
