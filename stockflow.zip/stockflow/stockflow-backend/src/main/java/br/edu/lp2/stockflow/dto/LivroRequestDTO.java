package br.edu.lp2.stockflow.dto;

import br.edu.lp2.stockflow.model.TipoEstoque;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
public class LivroRequestDTO {
    @NotBlank(message = "Titulo e obrigatorio")
    private String titulo;

    @NotBlank(message = "Autor e obrigatorio")
    private String autor;

    @NotBlank(message = "Categoria e obrigatoria")
    private String categoria;

    @NotNull(message = "Preco e obrigatorio")
    @DecimalMin(value = "0.01", message = "Preco deve ser maior que zero")
    private BigDecimal preco;

    @Min(value = 0, message = "Quantidade nao pode ser negativa")
    private int quantidade;

    @Min(value = 0, message = "Estoque minimo nao pode ser negativo")
    private int estoqueMinimo;

    @NotNull(message = "Tipo de estoque e obrigatorio")
    private TipoEstoque tipoEstoque;

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public BigDecimal getPreco() {
        return preco;
    }

    public void setPreco(BigDecimal preco) {
        this.preco = preco;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public int getEstoqueMinimo() {
        return estoqueMinimo;
    }

    public void setEstoqueMinimo(int estoqueMinimo) {
        this.estoqueMinimo = estoqueMinimo;
    }

    public TipoEstoque getTipoEstoque() {
        return tipoEstoque;
    }

    public void setTipoEstoque(TipoEstoque tipoEstoque) {
        this.tipoEstoque = tipoEstoque;
    }
}
