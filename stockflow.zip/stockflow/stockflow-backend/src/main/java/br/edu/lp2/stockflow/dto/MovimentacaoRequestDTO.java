package br.edu.lp2.stockflow.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class MovimentacaoRequestDTO {
    @NotNull(message = "ID do livro e obrigatorio")
    private Long livroId;

    @Min(value = 1, message = "Quantidade deve ser maior que zero")
    private int quantidade;

    public Long getLivroId() {
        return livroId;
    }

    public void setLivroId(Long livroId) {
        this.livroId = livroId;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
}
