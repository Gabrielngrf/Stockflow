package br.edu.lp2.stockflow.controller;

import br.edu.lp2.stockflow.dto.MovimentacaoRequestDTO;
import br.edu.lp2.stockflow.dto.MovimentacaoResponseDTO;
import br.edu.lp2.stockflow.model.TipoMovimentacao;
import br.edu.lp2.stockflow.service.MovimentacaoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/movimentacoes")
public class MovimentacaoController {
    private final MovimentacaoService movimentacaoService;

    public MovimentacaoController(MovimentacaoService movimentacaoService) {
        this.movimentacaoService = movimentacaoService;
    }

    @GetMapping
    public List<MovimentacaoResponseDTO> listar(@RequestParam(name = "tipo", required = false) TipoMovimentacao tipo) {
        return movimentacaoService.listar(tipo);
    }

    @PostMapping("/entrada")
    @ResponseStatus(HttpStatus.CREATED)
    public MovimentacaoResponseDTO entrada(@Valid @RequestBody MovimentacaoRequestDTO request) {
        return movimentacaoService.registrarEntrada(request);
    }

    @PostMapping("/saida")
    @ResponseStatus(HttpStatus.CREATED)
    public MovimentacaoResponseDTO saida(@Valid @RequestBody MovimentacaoRequestDTO request) {
        return movimentacaoService.registrarSaida(request);
    }
}
