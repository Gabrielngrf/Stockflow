package br.edu.lp2.stockflow.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI stockflowOpenApi() {
        return new OpenAPI()
                .info(new Info()
                        .title("StockFlow API")
                        .description("API para controle de estoque de livros em livrarias.")
                        .version("1.0.0")
                        .contact(new Contact().name("Disciplina de Linguagem de Programacao 2")));
    }
}
