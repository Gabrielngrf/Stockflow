package br.edu.lp2.stockflow.repository;

import br.edu.lp2.stockflow.model.Livro;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@Repository
public class LivroRepository extends JsonFileRepository<Livro> {

    public LivroRepository(ObjectMapper objectMapper,
                           @Value("${stockflow.data.directory:data}") String dataDirectory) {
        super(objectMapper, dataDirectory, "livros.json", Livro.class);
    }

    public List<Livro> findAll() {
        return lerTodos();
    }

    public Optional<Livro> findById(Long id) {
        return lerTodos().stream()
                .filter(livro -> livro.getId().equals(id))
                .findFirst();
    }

    public List<Livro> findByTitulo(String titulo) {
        String termo = titulo == null ? "" : titulo.toLowerCase();
        return lerTodos().stream()
                .filter(livro -> livro.getTitulo().toLowerCase().contains(termo))
                .toList();
    }

    public Livro save(Livro livro) {
        List<Livro> livros = lerTodos();
        if (livro.getId() == null) {
            livro.setId(proximoId(livros));
            livros.add(livro);
        } else {
            livros = livros.stream()
                    .map(atual -> atual.getId().equals(livro.getId()) ? livro : atual)
                    .toList();
        }
        salvarTodos(livros);
        return livro;
    }

    public void deleteById(Long id) {
        List<Livro> livros = lerTodos().stream()
                .filter(livro -> !livro.getId().equals(id))
                .toList();
        salvarTodos(livros);
    }

    private Long proximoId(List<Livro> livros) {
        return livros.stream()
                .map(Livro::getId)
                .max(Comparator.naturalOrder())
                .orElse(0L) + 1;
    }
}
