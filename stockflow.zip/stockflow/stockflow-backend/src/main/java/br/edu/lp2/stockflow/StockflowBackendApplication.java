package br.edu.lp2.stockflow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockflowBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(StockflowBackendApplication.class, args);
    }
}
