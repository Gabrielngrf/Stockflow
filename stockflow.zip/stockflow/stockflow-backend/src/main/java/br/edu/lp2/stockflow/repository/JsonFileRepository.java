package br.edu.lp2.stockflow.repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public abstract class JsonFileRepository<T> {
    private final ObjectMapper objectMapper;
    private final Path arquivo;
    private final Class<T> entityClass;

    protected JsonFileRepository(ObjectMapper objectMapper,
                                 @Value("${stockflow.data.directory:data}") String dataDirectory,
                                 String fileName,
                                 Class<T> entityClass) {
        this.objectMapper = objectMapper;
        this.arquivo = Path.of(dataDirectory, fileName);
        this.entityClass = entityClass;
        inicializarArquivo();
    }

    protected synchronized List<T> lerTodos() {
        try {
            if (Files.size(arquivo) == 0) {
                return new ArrayList<>();
            }
            return objectMapper.readValue(
                    arquivo.toFile(),
                    objectMapper.getTypeFactory().constructCollectionType(List.class, entityClass)
            );
        } catch (IOException e) {
            throw new IllegalStateException("Nao foi possivel ler o arquivo " + arquivo, e);
        }
    }

    protected synchronized void salvarTodos(List<T> itens) {
        try {
            objectMapper.writerWithDefaultPrettyPrinter().writeValue(arquivo.toFile(), itens);
        } catch (IOException e) {
            throw new IllegalStateException("Nao foi possivel salvar o arquivo " + arquivo, e);
        }
    }

    private void inicializarArquivo() {
        try {
            Files.createDirectories(arquivo.getParent());
            if (Files.notExists(arquivo)) {
                Files.writeString(arquivo, "[]");
            }
        } catch (IOException e) {
            throw new IllegalStateException("Nao foi possivel inicializar o arquivo " + arquivo, e);
        }
    }
}
