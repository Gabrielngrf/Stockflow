package br.edu.lp2.stockflow.model;

import java.time.LocalDateTime;

public class Movimentacao {
    private Long id;
    private Long livroId;
    private TipoMovimentacao tipo;
    private int quantidade;
    private LocalDateTime dataHora;

    public Movimentacao() {
    }

    public Movimentacao(Long id, Long livroId, TipoMovimentacao tipo, int quantidade, LocalDateTime dataHora) {
        this.id = id;
        this.livroId = livroId;
        this.tipo = tipo;
        this.quantidade = quantidade;
        this.dataHora = dataHora;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getLivroId() {
        return livroId;
    }

    public void setLivroId(Long livroId) {
        this.livroId = livroId;
    }

    public TipoMovimentacao getTipo() {
        return tipo;
    }

    public void setTipo(TipoMovimentacao tipo) {
        this.tipo = tipo;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }
}
