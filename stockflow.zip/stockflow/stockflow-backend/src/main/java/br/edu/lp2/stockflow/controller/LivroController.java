package br.edu.lp2.stockflow.controller;

import br.edu.lp2.stockflow.dto.ClassificacaoRequestDTO;
import br.edu.lp2.stockflow.dto.ComentarioRequestDTO;
import br.edu.lp2.stockflow.dto.LivroRequestDTO;
import br.edu.lp2.stockflow.dto.LivroResponseDTO;
import br.edu.lp2.stockflow.service.LivroService;
import br.edu.lp2.stockflow.service.ImagemService;
import jakarta.validation.Valid;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Path;
import java.nio.file.Files;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/livros")
public class LivroController {
    private final LivroService livroService;
    private final ImagemService imagemService;

    public LivroController(LivroService livroService, ImagemService imagemService) {
        this.livroService = livroService;
        this.imagemService = imagemService;
    }

    @GetMapping
    public List<LivroResponseDTO> listar(@RequestParam(name = "titulo", required = false) String titulo) {
        return livroService.listar(titulo);
    }

    @GetMapping("/{id}")
    public LivroResponseDTO buscarPorId(@PathVariable("id") Long id) {
        return livroService.buscarPorId(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public LivroResponseDTO cadastrar(@Valid @RequestBody LivroRequestDTO request) {
        return livroService.cadastrar(request);
    }

    @PutMapping("/{id}")
    public LivroResponseDTO atualizar(@PathVariable("id") Long id, @Valid @RequestBody LivroRequestDTO request) {
        return livroService.atualizar(id, request);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void remover(@PathVariable("id") Long id) {
        livroService.remover(id);
    }

    @GetMapping("/alertas")
    public List<LivroResponseDTO> alertas() {
        return livroService.listarAlertas();
    }

    @GetMapping("/{id}/quantidade")
    public Map<String, Integer> consultarQuantidade(@PathVariable("id") Long id) {
        return Map.of("quantidade", livroService.consultarQuantidade(id));
    }

    @PostMapping(value = "/{id}/imagem", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public LivroResponseDTO salvarImagem(@PathVariable("id") Long id, @RequestParam("arquivo") MultipartFile arquivo) {
        return livroService.salvarImagem(id, arquivo);
    }

    @GetMapping("/{id}/imagem")
    public ResponseEntity<Resource> buscarImagem(@PathVariable("id") Long id) {
        LivroResponseDTO livro = livroService.buscarPorId(id);
        Path caminho = imagemService.resolverImagem(livro.getImagemPath());
        MediaType mediaType = MediaType.APPLICATION_OCTET_STREAM;
        try {
            String contentType = Files.probeContentType(caminho);
            if (contentType != null) {
                mediaType = MediaType.parseMediaType(contentType);
            }
        } catch (Exception ignored) {
            mediaType = MediaType.APPLICATION_OCTET_STREAM;
        }
        return ResponseEntity.ok()
                .contentType(mediaType)
                .body(new FileSystemResource(caminho));
    }

    @PostMapping("/{id}/comentarios")
    public LivroResponseDTO adicionarComentario(@PathVariable("id") Long id, @Valid @RequestBody ComentarioRequestDTO request) {
        return livroService.adicionarComentario(id, request);
    }

    @PostMapping("/{id}/classificacoes")
    public LivroResponseDTO classificar(@PathVariable("id") Long id, @Valid @RequestBody ClassificacaoRequestDTO request) {
        return livroService.classificar(id, request);
    }
}
