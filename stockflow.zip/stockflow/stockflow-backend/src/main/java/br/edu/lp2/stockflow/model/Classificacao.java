package br.edu.lp2.stockflow.model;

import java.time.LocalDateTime;

public class Classificacao {
    private String usuario;
    private int nota;
    private boolean alterada;
    private LocalDateTime dataHora;

    public Classificacao() {
    }

    public Classificacao(String usuario, int nota, boolean alterada, LocalDateTime dataHora) {
        this.usuario = usuario;
        this.nota = nota;
        this.alterada = alterada;
        this.dataHora = dataHora;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }

    public boolean isAlterada() {
        return alterada;
    }

    public void setAlterada(boolean alterada) {
        this.alterada = alterada;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }
}
