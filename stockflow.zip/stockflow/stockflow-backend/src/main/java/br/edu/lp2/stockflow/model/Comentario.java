package br.edu.lp2.stockflow.model;

import java.time.LocalDateTime;

public class Comentario {
    private String autor;
    private String texto;
    private LocalDateTime dataHora;

    public Comentario() {
    }

    public Comentario(String autor, String texto, LocalDateTime dataHora) {
        this.autor = autor;
        this.texto = texto;
        this.dataHora = dataHora;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }
}
