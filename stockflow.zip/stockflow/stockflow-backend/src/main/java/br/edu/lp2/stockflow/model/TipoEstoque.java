package br.edu.lp2.stockflow.model;

public enum TipoEstoque {
    FISICO,
    INTERNO
}
