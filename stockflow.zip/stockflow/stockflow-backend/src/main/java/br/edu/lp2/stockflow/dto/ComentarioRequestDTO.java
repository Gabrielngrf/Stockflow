package br.edu.lp2.stockflow.dto;

import jakarta.validation.constraints.NotBlank;

public class ComentarioRequestDTO {
    @NotBlank(message = "Autor do comentario e obrigatorio")
    private String autor;

    @NotBlank(message = "Texto do comentario e obrigatorio")
    private String texto;

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }
}
