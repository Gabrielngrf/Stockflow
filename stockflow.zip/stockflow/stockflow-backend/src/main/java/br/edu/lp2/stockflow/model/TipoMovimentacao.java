package br.edu.lp2.stockflow.model;

public enum TipoMovimentacao {
    ENTRADA,
    SAIDA
}
