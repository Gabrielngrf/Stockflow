package br.edu.lp2.stockflow.dto;

import java.time.LocalDateTime;

public class ComentarioResponseDTO {
    private String autor;
    private String texto;
    private LocalDateTime dataHora;

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }
}
