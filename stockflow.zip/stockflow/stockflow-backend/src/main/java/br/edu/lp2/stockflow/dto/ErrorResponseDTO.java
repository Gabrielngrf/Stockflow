package br.edu.lp2.stockflow.dto;

import java.time.LocalDateTime;
import java.util.List;

public class ErrorResponseDTO {
    private LocalDateTime timestamp;
    private int status;
    private String erro;
    private List<String> mensagens;

    public ErrorResponseDTO(LocalDateTime timestamp, int status, String erro, List<String> mensagens) {
        this.timestamp = timestamp;
        this.status = status;
        this.erro = erro;
        this.mensagens = mensagens;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public int getStatus() {
        return status;
    }

    public String getErro() {
        return erro;
    }

    public List<String> getMensagens() {
        return mensagens;
    }
}
