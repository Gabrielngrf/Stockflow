package br.edu.lp2.stockflow.repository;

import br.edu.lp2.stockflow.model.Movimentacao;
import br.edu.lp2.stockflow.model.TipoMovimentacao;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.util.Comparator;
import java.util.List;

@Repository
public class MovimentacaoRepository extends JsonFileRepository<Movimentacao> {

    public MovimentacaoRepository(ObjectMapper objectMapper,
                                  @Value("${stockflow.data.directory:data}") String dataDirectory) {
        super(objectMapper, dataDirectory, "movimentacoes.json", Movimentacao.class);
    }

    public List<Movimentacao> findAll() {
        return lerTodos();
    }

    public List<Movimentacao> findByTipo(TipoMovimentacao tipo) {
        return lerTodos().stream()
                .filter(movimentacao -> movimentacao.getTipo() == tipo)
                .toList();
    }

    public Movimentacao save(Movimentacao movimentacao) {
        List<Movimentacao> movimentacoes = lerTodos();
        movimentacao.setId(proximoId(movimentacoes));
        movimentacoes.add(movimentacao);
        salvarTodos(movimentacoes);
        return movimentacao;
    }

    private Long proximoId(List<Movimentacao> movimentacoes) {
        return movimentacoes.stream()
                .map(Movimentacao::getId)
                .max(Comparator.naturalOrder())
                .orElse(0L) + 1;
    }
}
