package br.edu.lp2.stockflow.service;

import br.edu.lp2.stockflow.dto.MovimentacaoRequestDTO;
import br.edu.lp2.stockflow.dto.MovimentacaoResponseDTO;
import br.edu.lp2.stockflow.exception.RegraNegocioException;
import br.edu.lp2.stockflow.model.Livro;
import br.edu.lp2.stockflow.model.Movimentacao;
import br.edu.lp2.stockflow.model.TipoMovimentacao;
import br.edu.lp2.stockflow.repository.LivroRepository;
import br.edu.lp2.stockflow.repository.MovimentacaoRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class MovimentacaoService {
    private final MovimentacaoRepository movimentacaoRepository;
    private final LivroRepository livroRepository;
    private final LivroService livroService;

    public MovimentacaoService(MovimentacaoRepository movimentacaoRepository,
                               LivroRepository livroRepository,
                               LivroService livroService) {
        this.movimentacaoRepository = movimentacaoRepository;
        this.livroRepository = livroRepository;
        this.livroService = livroService;
    }

    public List<MovimentacaoResponseDTO> listar(TipoMovimentacao tipo) {
        List<Movimentacao> movimentacoes = tipo == null
                ? movimentacaoRepository.findAll()
                : movimentacaoRepository.findByTipo(tipo);
        return movimentacoes.stream().map(this::toResponse).toList();
    }

    public MovimentacaoResponseDTO registrarEntrada(MovimentacaoRequestDTO request) {
        return registrar(request, TipoMovimentacao.ENTRADA);
    }

    public MovimentacaoResponseDTO registrarSaida(MovimentacaoRequestDTO request) {
        return registrar(request, TipoMovimentacao.SAIDA);
    }

    private MovimentacaoResponseDTO registrar(MovimentacaoRequestDTO request, TipoMovimentacao tipo) {
        Livro livro = livroService.buscarEntidadePorId(request.getLivroId());
        int novaQuantidade = tipo == TipoMovimentacao.ENTRADA
                ? livro.getQuantidade() + request.getQuantidade()
                : livro.getQuantidade() - request.getQuantidade();

        if (novaQuantidade < 0) {
            throw new RegraNegocioException("Quantidade insuficiente em estoque para realizar a saida");
        }

        livro.setQuantidade(novaQuantidade);
        livroRepository.save(livro);

        Movimentacao movimentacao = new Movimentacao();
        movimentacao.setLivroId(livro.getId());
        movimentacao.setTipo(tipo);
        movimentacao.setQuantidade(request.getQuantidade());
        movimentacao.setDataHora(LocalDateTime.now());

        return toResponse(movimentacaoRepository.save(movimentacao));
    }

    private MovimentacaoResponseDTO toResponse(Movimentacao movimentacao) {
        MovimentacaoResponseDTO dto = new MovimentacaoResponseDTO();
        dto.setId(movimentacao.getId());
        dto.setLivroId(movimentacao.getLivroId());
        dto.setTipo(movimentacao.getTipo());
        dto.setQuantidade(movimentacao.getQuantidade());
        dto.setDataHora(movimentacao.getDataHora());
        livroRepository.findById(movimentacao.getLivroId())
                .ifPresent(livro -> dto.setTituloLivro(livro.getTitulo()));
        return dto;
    }
}
