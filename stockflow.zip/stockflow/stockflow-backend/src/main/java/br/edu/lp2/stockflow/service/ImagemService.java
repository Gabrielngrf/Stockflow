package br.edu.lp2.stockflow.service;

import br.edu.lp2.stockflow.exception.RegraNegocioException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Set;
import java.util.UUID;

@Service
public class ImagemService {
    private static final Set<String> EXTENSOES_PERMITIDAS = Set.of(".jpg", ".jpeg", ".png", ".gif", ".webp");

    private final Path diretorioImagens;

    public ImagemService(@Value("${stockflow.data.directory:data}") String dataDirectory) {
        this.diretorioImagens = Path.of(dataDirectory, "imagens");
    }

    public String salvarImagem(MultipartFile arquivo) {
        if (arquivo == null || arquivo.isEmpty()) {
            throw new RegraNegocioException("Arquivo de imagem e obrigatorio");
        }

        String nomeOriginal = arquivo.getOriginalFilename() == null ? "" : arquivo.getOriginalFilename();
        String extensao = extrairExtensao(nomeOriginal).toLowerCase();
        if (!EXTENSOES_PERMITIDAS.contains(extensao)) {
            throw new RegraNegocioException("Formato de imagem invalido. Use JPG, PNG, GIF ou WEBP");
        }

        try {
            Files.createDirectories(diretorioImagens);
            String nomeArquivo = UUID.randomUUID() + extensao;
            Path destino = diretorioImagens.resolve(nomeArquivo);
            Files.copy(arquivo.getInputStream(), destino);
            return "imagens/" + nomeArquivo;
        } catch (IOException e) {
            throw new IllegalStateException("Nao foi possivel salvar a imagem", e);
        }
    }

    public Path resolverImagem(String imagemPath) {
        if (imagemPath == null || imagemPath.isBlank()) {
            throw new RegraNegocioException("Livro nao possui imagem cadastrada");
        }
        Path caminho = diretorioImagens.getParent().resolve(imagemPath).normalize();
        if (!caminho.startsWith(diretorioImagens.getParent().normalize()) || Files.notExists(caminho)) {
            throw new RegraNegocioException("Imagem nao encontrada");
        }
        return caminho;
    }

    private String extrairExtensao(String nomeArquivo) {
        int indice = nomeArquivo.lastIndexOf('.');
        return indice >= 0 ? nomeArquivo.substring(indice) : "";
    }
}
