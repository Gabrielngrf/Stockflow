package br.edu.lp2.stockflow.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

public class ClassificacaoRequestDTO {
    @NotBlank(message = "Usuario e obrigatorio")
    private String usuario;

    @Min(value = 1, message = "Classificacao minima e 1")
    @Max(value = 5, message = "Classificacao maxima e 5")
    private int nota;

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }
}
